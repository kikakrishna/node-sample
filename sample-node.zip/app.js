// const express = require('express');
// const app = express();
// const port = 5000;

// app.get('/', (req, res) => res.send('Hello World!'));

// app.get("/url", (req, res, next) => {
//     res.json(["Tony","Lisa","Michael","Ginger","Food"]);
//    });

// app.listen(port, () => console.log(`Example app listening on port ${port}!`));


//--------------------------------------------------------------------------------


// var express = require('express');
// var app = express(); 
// var fs = require("fs");

// var user = {
//    "user4" : {
//       "name" : "mohit",
//       "password" : "password4",
//       "profession" : "teacher",
//       "id": 4
//    }
// }

// app.post('/addUser', function (req, res) {
//    // First read existing users.
//    fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
//       data = JSON.parse( data );
//       data["user4"] = user["user4"];
//       console.log( data );
//       res.end( JSON.stringify(data));
//    });
// })

// var server = app.listen(8081, function () {
//    var host = server.address().address
//    var port = server.address().port
//    console.log("Example app listening at http://%s:%s", host, port)
// })



//-----------------------------------------------------------------------

// --------------------------------------------------------------
// var express = require('express');
// var app = express();
// var PORT = 5000;
  
// app.get('/', (req, res) => {
//   res.send(["Tony","Lisa","Michael","Ginger","Food"])
// })
  
// app.listen(PORT, function(err){
//     if (err) console.log(err);
//     console.log("Server listening on PORT", PORT);
// }); 
// -----------------------------------------------------------------------

// const {createpool} = require('mysql');

const {createPool} = require('mysql');


const pool = createPool({
  host: "localhost",
  user: "root",
  password: "root",
  connectionLimit: 10
})

pool.query('select * from db.sample', (err,res)=>{
  return console.log(err)
})